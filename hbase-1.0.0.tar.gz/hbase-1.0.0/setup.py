# -*- coding: utf-8 -*-
from distutils.core import setup

setup(name='hbase', version='1.0.0', packages=['hbase'], author='sfck', author_email='simolx@163.com', description='hbase thrift python client for hyperbase')
